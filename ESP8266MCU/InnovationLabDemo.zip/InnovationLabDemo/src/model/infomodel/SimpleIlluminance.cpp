// SimpleIlluminance

#include "SimpleIlluminance.h"

using namespace com_bosch_iotacademy_tutorial;

SimpleIlluminance::SimpleIlluminance() {}

String SimpleIlluminance::serialize() {}
