// SimpleHumidity

#include "SimpleHumidity.h"

using namespace com_bosch_iotacademy_tutorial;

SimpleHumidity::SimpleHumidity() {}

String SimpleHumidity::serialize() {}
