// SimpleIlluminance

#include "SimpleTemperature.h"

using namespace com_bosch_iotacademy_tutorial;

SimpleTemperature::SimpleTemperature() {}

String SimpleTemperature::serialize() {}
